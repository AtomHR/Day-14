import UIKit

let opposites = [
    "Mario": "Wario",
    "Luigi": "Waluigi"
]

let peachOpposite = opposites["Peach"]

if let marioOpposite = opposites["Mario"] {
    print("Mario's opposite is \(marioOpposite)")
}

var username: String? = nil

if let unwrappedName = username {
    print("We got a user: \(unwrappedName)")
} else {
    print("The optional was empty.")
}


/*
 func square(number: Int) -> Int {
 number * number
 }
 
 var number: Int? = 3
 print(square(number: number)
 */


func getUsername() -> String? {
    "Taylor"
}

if let username = getUsername() {
    print("Username is \(username)")
} else {
    print("No username")
}

//print(username)


func printSquare(of number: Int?) {
    guard let number = number else {
        print("Missing input")
        return
    }

    print("\(number) x \(number) is \(number * number)")
}


var z: Int? = 50
printSquare(of: z)
printSquare(of: nil)

func getMeaningOfLife() -> Int? {
    42
}

func printMeaningOfLife() {
    if let name = getMeaningOfLife() {
        print(name)
    }
}

printMeaningOfLife()


func printMeaningOfLife_1() {
    guard let name = getMeaningOfLife() else {
        return
    }

    print(name)
}

printMeaningOfLife_1()


func uppercase(string: String?) -> String? {
    guard let string = string else {
        return nil
    }
    return string.uppercased()
}
if let result = uppercase(string: "Hello") {
    print(result)
}


func add3(to number: Int?) -> Int {
    guard let number = number else {
        return 3
    }
    return number + 3
}
let added = add3(to: 5)
print(added)


let captains = [
    "Enterprise": "Picard",
    "Voyager": "Janeway",
    "Defiant": "Sisko"
]

let new = captains["Serenity"] ?? "N/A."

print(new)


let tvShows = ["Archer", "Babylon 5", "Ted Lasso"]
let favorite = tvShows.randomElement() ?? "None"


let name_1: [String] = []
let name_2 = name_1.randomElement() //?? "No name"
print(name_2 ?? "mdwp")

/*
struct Book {
    let title: String
    let author: String
}

let book = Book(title: "Beowulf", author: "")
let author = book.author
let author_1 = author.isEmpty ? "нет автора" : author
print(author_1)
*/

struct Book {
    let title: String
    let author: String?
}
 /*
let book = Book(title: "Beowulf", author: nil)
let author = book.author ?? "Anonymous"
print(author)


let input = ""
let number = Int(input) ?? 0
print(number)
*/


let scores = ["Picard": 800, "Data": 7000, "Troi": 900]
let crusherScore = scores["Data"] ?? 0
print(crusherScore)


let names = ["Arya", "Bran", "Robb", "Sansa"]
let names_1: [String] = [""]

let chosen = names_1.randomElement()?.uppercased() ?? "No one"
print("Next in line: \(chosen)")

struct Book1 {
    let title: String
    let author: String?
}

var book: Book1? = nil
let author = book?.author?.first?.uppercased() ?? "A"
print(author)

var book_1: Book1? = Book1(title: "The Alchemist", author: "Paulo Coelho")
let author_1 = book_1?.author?.first?.uppercased() ?? "A"
print(author_1)

var book_2: Book1? = Book1(title: "berserk", author: nil)
let author_2 = book_2?.author?.first?.uppercased() ?? "A"
print(author_2)


let names_0 = ["Vincent": "van Gogh", "Pablo": "Picasso", "Claude": "Monet"]
let surnameLetter = names_0["Vincent1"]?.first?.uppercased() ?? "not bat"
print(surnameLetter)


enum UserError: Error {
    case badID, networkFailed
}

func getUser(id: Int) throws -> String {
    throw UserError.networkFailed
}

if let user = try? getUser(id: 23) {
    print("User: \(user)")
}
