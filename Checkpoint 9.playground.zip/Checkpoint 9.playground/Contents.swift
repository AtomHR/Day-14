import UIKit

var arry = [1,2,3,4,5]

func ArryElement(_ new: [Int]?) -> Int { return new?.randomElement() ?? Int.random(in: 0...100)}

ArryElement(arry)

var ar: [Int]?

ArryElement(ar)
